#include "arduino_secrets.h"

#define TRIG_PIN 9
#define ECHO_PIN 10
#define FAN_PIN 3
#define RED_LED 4
#define GREEN_LED 5

unsigned long handDetectedTime = 0;
unsigned long handRemovedTime = 0;
bool fanState = false;

void setup() {
  pinMode(TRIG_PIN, OUTPUT);
  pinMode(ECHO_PIN, INPUT);
  pinMode(FAN_PIN, OUTPUT);
  pinMode(RED_LED, OUTPUT);
  pinMode(GREEN_LED, OUTPUT);

  digitalWrite(FAN_PIN, LOW);
  digitalWrite(RED_LED, HIGH);  //Initially ON
  digitalWrite(GREEN_LED, LOW); //Initially OFF
  Serial.begin(9600);
}

long getDistance() {
  digitalWrite(TRIG_PIN, LOW);
  delayMicroseconds(2);
  digitalWrite(TRIG_PIN, HIGH);
  delayMicroseconds(10);
  digitalWrite(TRIG_PIN, LOW);

  long duration = pulseIn(ECHO_PIN, HIGH);
  long distance = duration * 0.034 / 2; //Convert to cm
  return distance;
}

void loop() {
  long distance = getDistance();
  Serial.print("Distance: ");
  Serial.println(distance);

//Consider object close if distance < 10cm
if (distance < 10) {
  if (!fanState && (millis() - handRemovedTime > 1000)) {
    if (handDetectedTime == 0) {
      handDetectedTime = millis();
    }
    if (millis() - handDetectedTime > 1000) {
      // Turn ON fan
      digitalWrite(FAN_PIN, HIGH);
      digitalWrite(GREEN_LED, HIGH);
      digitalWrite(RED_LED, LOW);
      fanState = true;
    }
  }
} else {
  if (fanState && (millis() - handDetectedTime > 1000)) {
    if (handRemovedTime == 0) {
      handRemovedTime = millis();
      Serial.println("RED HIGH");
      
    }
    if (millis() - handRemovedTime > 1000) {
      // Turn OFF fan
      digitalWrite(FAN_PIN, LOW);
      digitalWrite(GREEN_LED, LOW);
      digitalWrite(RED_LED, HIGH);
      Serial.println("RED HIGH");
      fanState = false;
    }
  }
  
}

// Reset timers if states change
if (distance >= 10) handDetectedTime = 0;
if (distance < 10) handRemovedTime = 0;

delay(100); //Small delay for stability
}